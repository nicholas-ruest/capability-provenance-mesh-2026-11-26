#!/usr/bin/env bash
set -euo pipefail
r=$1; p="$r/probes/src/sigstore_cosign"; img=ghcr.io/sigstore/cosign/cosign@sha256:7d08ec40d6f6fd9ced81a498c367ee6d4dd90d73218f58a791f78661bdbef769
test "$(git -C "$p" rev-parse HEAD)" = 252f10a80ba871152a12e5ee324ad1e02c85d079
if podman run --rm --network=none --user 0:0 -v "$r:/run:z" "$img" verify-blob --key /run/probes/cosign/probe.pub --bundle /run/probes/cosign/probe.bundle --insecure-ignore-tlog /run/research/architecture-options.md; then echo unexpected-success >&2; exit 1; else echo tamper-rejected; fi
