#!/usr/bin/env bash
set -euo pipefail
r=$1; p="$r/probes/src/NVIDIA_SkillSpector"; o=$(mktemp)
test "$(git -C "$p" rev-parse HEAD)" = 48e0f942ea1f5fdb7aa096a6f65a0adeda2ecc4e
"$r/probes/venv-skillspector/bin/skillspector" scan "$p/tests/fixtures/safe_skill" --no-llm --format json --output "$o"
python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); assert d["risk_assessment"]["recommendation"]=="SAFE"; print(json.dumps(d["risk_assessment"],sort_keys=True))' "$o"
